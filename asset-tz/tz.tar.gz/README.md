Requires python3, requests and Mako.

Generates `output.html`.
