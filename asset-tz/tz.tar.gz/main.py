#!/usr/bin/env python3
import os
import time
from decimal import Decimal
import requests
from mako.template import Template


PROGRAM_DIR = os.path.abspath(os.path.dirname(__file__))


ASSETS = {
    'BTC': 1,
    'XRP': 15000,
    'XMR': 50,
    'DASH': 30,
}


RESULTANT_ASSETS = [
    'USDT',
    'BTC',
    'XRP',
    'XMR',
    'DASH',
]


# Queries for the prices and returns them as a `{symbol: price}` dictionary.
def query_prices():
    r = requests.get('https://www.binance.com/api/v3/ticker/price')
    r.raise_for_status()
    result = r.json()
    return {datum['symbol']: Decimal(datum['price']) for datum in result}


# Converts `amount` in `from_asset` to `to_asset` using the prices dictionary `prices`.
# If `directly` is `True`, prohibits indirect conversion (that is, using a third assert).
def convert(prices, amount, from_asset, to_asset, *, directly=False):
    if from_asset == to_asset:
        return amount

    try:
        return amount * prices[from_asset + to_asset]
    except KeyError:
        pass

    try:
        return amount / prices[to_asset + from_asset]
    except KeyError:
        pass

    if directly:
        raise ValueError(f'cannot convert {from_asset} to {to_asset} directly')

    return (
        amount * convert(prices, amount, from_asset, 'BTC', directly=True)
               / convert(prices, amount, to_asset,   'BTC', directly=True))


def main():
    template = Template(
        filename=os.path.join(PROGRAM_DIR, 'template.mako'),
        input_encoding='utf-8')
    prices = query_prices()
    body = template.render(
        assets=ASSETS,
        resultant_assets=RESULTANT_ASSETS,
        values={
            to_asset: {
                from_asset: convert(prices, Decimal(amount), from_asset, to_asset)
                for from_asset, amount in ASSETS.items()
            }
            for to_asset in RESULTANT_ASSETS
        },
        render_amount=lambda x: f'{x:.4f}')

    with open('output.html', 'w') as f:
        f.write(body)


if __name__ == '__main__':
    main()
